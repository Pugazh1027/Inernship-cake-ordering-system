# Cake Ordering System – Mobile App Prototype

A clickable UI/UX prototype of a cake ordering mobile app, built as a summer internship project at Media Wave Technologies, Tiruchirappalli.

## Features
- Splash, Login, Sign Up (with validation) and Continue as guest
- Home with search and occasion shortcuts (Birthday, Wedding, Anniversary, Cupcakes)
- Bakery menu and cake customisation (weight, flavour, eggless, message, delivery slot)
- Cart, 4-step checkout, payment method selection (UPI, Card, Wallet)
- Order confirmation, live order tracking timeline, delivery rating and reorder

## Tech
HTML, CSS and vanilla JavaScript in a single file. No build step or dependencies.

## Run
Open `cake-ordering-app.html` in any browser.

## Author
Pugazhvadivu E, B.E. CSE, University College of Engineering (BIT Campus), Anna University
